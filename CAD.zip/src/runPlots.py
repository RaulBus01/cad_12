import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV data
file_path = 'CAD\src\delays.csv'  # Replace with your file path
data = pd.read_csv(file_path)

# Compute average delay by UserIndex
avg_delay_user = data.groupby('UserIndex')['Delay'].mean()

# Compute average delay by User Weight 
avg_delay_weight = data.groupby('Weight')['Delay'].mean()

# Plot average delay by UserIndex
plt.figure(figsize=(10, 5))
avg_delay_user.plot(kind='bar', color='skyblue', edgecolor='black')
plt.title('Average User Delay')
plt.xlabel('UserIndex')
plt.ylabel('Average Delay')
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# Plot average delay by Weight
plt.figure(figsize=(10, 5))
avg_delay_weight.plot(kind='line', marker='o', color='green', linewidth=2)
plt.title('Average Delay by User Weight')
plt.xlabel('Weight')
plt.ylabel('Average Delay')
plt.grid(axis='both', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
